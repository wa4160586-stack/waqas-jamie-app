import React, { useState } from 'react';
import { SafeAreaView, Text, TextInput, Button, View } from 'react-native';

export default function App() {
  const [input, setInput] = useState('');
  const [reply, setReply] = useState('');

  async function sendMessage() {
    // Replace with your real backend URL if you have one
    const res = await fetch('https://your-backend-url/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: input })
    });
    const data = await res.json();
    setReply(data.reply);
  }

  return (
    <SafeAreaView style={{ flex: 1, justifyContent: 'center', padding: 16 }}>
      <Text style={{ fontWeight: 'bold', fontSize: 24 }}>
        Waqas Jamie Chat GPT
      </Text>
      <TextInput
        style={{ marginTop: 20, borderWidth: 1, padding: 10, borderRadius: 8 }}
        placeholder="Ask anything..."
        value={input}
        onChangeText={setInput}
      />
      <Button title="Search & Predict" onPress={sendMessage} />
      <View style={{ marginTop: 20 }}>
        <Text style={{ fontWeight: 'bold' }}>Waqas Jamie:</Text>
        <Text>{reply}</Text>
      </View>
    </SafeAreaView>
  );
}