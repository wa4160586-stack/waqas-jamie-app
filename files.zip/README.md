# Waqas Jamie Chat GPT

A universal AI-powered assistant to search, predict, and inform about everything A-Z.

## Features

- Search across apps and browsers
- AI-powered answers and predictions
- Future trend analysis
- ChatGPT-like interface

## Getting Started

- Run `npm install` in both `backend` and `frontend` folders.
- Start backend: `node server.js`
- Start frontend: `npm start`

---

**Note:** This is a conceptual MVP. Real cross-app and browser search requires OS-level integration, permission management, and advanced AI backends. For production, consider cloud hosting, security, and compliance.
