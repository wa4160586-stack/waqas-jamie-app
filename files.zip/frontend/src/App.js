import React, { useState } from 'react';
import ChatGPTWidget from './components/ChatGPTWidget';

function App() {
  return (
    <div style={{ padding: 20, fontFamily: 'Arial' }}>
      <h1>Waqas Jamie Chat GPT</h1>
      <p>
        Ask anything, search everywhere, get predictions and answers from A-Z!
      </p>
      <ChatGPTWidget />
    </div>
  );
}

export default App;