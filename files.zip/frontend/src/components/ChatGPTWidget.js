import React, { useState } from 'react';

export default function ChatGPTWidget() {
  const [input, setInput] = useState('');
  const [reply, setReply] = useState('');

  async function sendMessage() {
    const res = await fetch('http://localhost:5000/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: input })
    });
    const data = await res.json();
    setReply(data.reply);
  }

  return (
    <div>
      <input
        type="text"
        value={input}
        placeholder="Ask anything..."
        onChange={e => setInput(e.target.value)}
        style={{ width: 300 }}
      />
      <button onClick={sendMessage} style={{ marginLeft: 10 }}>
        Search & Predict
      </button>
      <div style={{ marginTop: 20 }}>
        <strong>Waqas Jamie:</strong> {reply}
      </div>
    </div>
  );
}