import React from 'react';

export default function ShareButton() {
  const appUrl = "https://waqasjamie.example.com";
  function share() {
    if (navigator.share) {
      navigator.share({
        title: "Waqas Jamie Chat GPT",
        text: "Try this amazing AI app!",
        url: appUrl,
      });
    } else {
      alert("Share this link: " + appUrl);
    }
  }
  return (
    <button onClick={share}>
      Share Waqas Jamie Chat GPT
    </button>
  );
}