const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 5000;

// Simple AI simulation (replace with OpenAI API integration)
app.use(cors());
app.use(express.json());

app.post('/chat', (req, res) => {
  const { message } = req.body;
  // Simulate answer
  res.json({ reply: `Waqas Jamie predicts: You asked "${message}". Here's an intelligent answer...` });
});

app.listen(PORT, () => console.log(`Waqas Jamie backend running on port ${PORT}`));