package com.example.voicesearch

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.app.NotificationCompat
import java.util.Locale

class VoiceService : Service() {
    private var recognizer: SpeechRecognizer? = null
    private val TAG = "VoiceService"
    private val CHANNEL_ID = "voice_search_channel"

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification = buildNotification("Voice search running")
        startForeground(1, notification)
        initRecognizer()
        startListening()
    }

    override fun onDestroy() {
        super.onDestroy()
        recognizer?.destroy()
        recognizer = null
    }

    private fun initRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { Log.d(TAG, "Ready") }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onBeginningOfSpeech() { Log.d(TAG, "Begin") }
                override fun onEndOfSpeech() { Log.d(TAG, "End") }
                override fun onError(error: Int) {
                    Log.d(TAG, "Error: $error")
                    // restart on error after short delay
                    startListening()
                }
                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        val text = matches[0].toLowerCase(Locale.getDefault())
                        handleCommand(text)
                    }
                    // continue listening
                    startListening()
                }
            })
        }
    }

    private fun startListening() {
        try {
            val intent = RecognizerIntent().apply {
                action = RecognizerIntent.ACTION_RECOGNIZE_SPEECH
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            Log.e(TAG, "startListening failed", e)
        }
    }

    private fun handleCommand(text: String) {
        Log.d(TAG, "Heard: $text")
        try {
            if (text.contains("open youtube") || text.contains("youtube")) {
                // extract query after keywords
                val q = text.replace("open youtube", "").replace("youtube", "").trim()
                val intent = Intent(Intent.ACTION_VIEW)
                if (q.isEmpty()) {
                    intent.data = android.net.Uri.parse("https://www.youtube.com")
                } else {
                    intent.data = android.net.Uri.parse("https://www.youtube.com/results?search_query=" + android.net.Uri.encode(q))
                }
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                return
            }

            if (text.contains("open") && text.contains("browser")) {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com"))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                return
            }

            // default: google search
            val intent = Intent(Intent.ACTION_WEB_SEARCH)
            intent.putExtra(android.app.SearchManager.QUERY, text)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "handleCommand error", e)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(CHANNEL_ID, "Voice Search", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(content: String): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Voice Search")
            .setContentText(content)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
